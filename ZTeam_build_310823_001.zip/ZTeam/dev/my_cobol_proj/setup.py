import os, sys

# RUN THIS MODULE IN ORDER TO INSTALL ALL DEPENDENCIES ---> USING "requirements.txt"


# get and set function for the current working directory of main program
def set_cwd():
    os.chdir(os.path.dirname(os.path.abspath(sys.argv[0])))


def get_cwd():
    return str(os.path.dirname(os.path.abspath(sys.argv[0])))

cwd=get_cwd()
print(cwd)

file_path=cwd+"\\requirements.txt --user"
command = "pip install -r "+file_path
print(command)

os.system(command)
