from common import func as f

# DECRYPT THE KEY FROM RANDOM KEY / ENCRYPTED KEY

# load the environment variables
f.load_envvar()

# Code to decrypt the key
api_key = f.get_openai_key()
print("Decrypted openai key : "+api_key)
