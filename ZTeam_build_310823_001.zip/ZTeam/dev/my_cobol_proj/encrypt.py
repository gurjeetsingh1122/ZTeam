from common import func as f

#########################################################
##     ENCRYPT TH KEY                                  ##
#########################################################
# load the environment variables

OPENAI_KEY="<provide your key here>"
f.load_envvar()
f.encrypt_openai_key(OPENAI_KEY)
