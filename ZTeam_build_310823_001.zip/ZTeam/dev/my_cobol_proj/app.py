import tkinter as tk
from tkinter import filedialog, scrolledtext
from tkinter.font import Font
from tkinter import ttk
from common import func as f
import openai
import json

class TextFileEditor:
    
    def __init__(self, root):
        self.root = root
        self.root.title("COBOL program analyser")

        self.create_widgets()

    # ---------------------------------------------------------------------------------------
    # FUNCTION - UI definition
    # ---------------------------------------------------------------------------------------

    def create_widgets(self):
        # Center content in the root window
        self.root.columnconfigure(0, weight=1)

        # Themed PanedWindow for the left and right panes
        self.panes = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        self.panes.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)

        # Frame for the left pane
        self.left_frame = ttk.Frame(self.panes)
        self.panes.add(self.left_frame, weight=1)

        # Label and scrolled text for original COBOL code in left pane
        self.label1 = ttk.Label(self.left_frame, text="Input:")
        self.label1.pack(pady=(10, 0), anchor=tk.W)

        # Create a subframe for the Browse and Clear buttons
        self.browse_clear_frame = ttk.Frame(self.left_frame)
        self.browse_clear_frame.pack(side=tk.BOTTOM, anchor=tk.W)

        # Browse button in left pane (aligned to the bottom left)
        self.load_button = ttk.Button(
            self.browse_clear_frame, text="Browse Cobol File", command=self.load_file)
        self.load_button.pack(side=tk.LEFT, padx=5, anchor=tk.W)

        # Button to clear text area contents and labels
        self.clear_button = ttk.Button(
            self.browse_clear_frame, text="Clear", command=self.clear_contents)
        self.clear_button.pack(side=tk.LEFT, padx=5, anchor=tk.W)

        # Label to display the path of the browsed file
        self.file_path_label = ttk.Label(self.left_frame, text="")
        self.file_path_label.pack(side=tk.BOTTOM, anchor=tk.W)

        self.text_area = scrolledtext.ScrolledText(
            self.left_frame, wrap=tk.NONE, width=40, height=20)
        self.text_area.pack(pady=5, anchor=tk.W, fill=tk.BOTH, expand=True)

        # Set background color and font for input pane
        self.text_area.configure(bg='Black', fg='#66FF00')
        input_font = Font(family="Courier New", size=11)
        self.text_area.configure(font=input_font)

        # Frame for the right pane
        self.right_frame = ttk.Frame(self.panes)
        self.panes.add(self.right_frame, weight=1)

        # Label and scrolled text for generated PseudoCode in right pane
        self.label2 = ttk.Label(self.right_frame, text="Output:")
        self.label2.pack(pady=(10, 0), anchor=tk.W)

        self.updated_text_area = scrolledtext.ScrolledText(
            self.right_frame, wrap=tk.NONE, width=40, height=20)
        self.updated_text_area.pack(
            pady=5, anchor=tk.W, fill=tk.BOTH, expand=True)

        # Set background color and font for output pane
        self.updated_text_area.configure(bg='light yellow')
        output_font = Font(family="Arial", size=11)
        self.updated_text_area.configure(font=output_font)

        # Create a subframe for buttons at the bottom of the right pane
        self.button_frame = ttk.Frame(self.right_frame)
        self.button_frame.pack(side=tk.BOTTOM, pady=10, anchor=tk.CENTER)

        # Display PseudoCode button in right pane
        self.display_updated_button = ttk.Button(
            self.button_frame, text="PseudoCode", command=self.display_updated)
        self.display_updated_button.pack(side=tk.LEFT, padx=5)

        # Display Summary button in right pane
        self.display_summary_button = ttk.Button(
            self.button_frame, text="Documented COBOL code", command=self.display_summary)
        self.display_summary_button.pack(side=tk.LEFT, padx=5)

        # Display Summary button in right pane
        self.display_etl_button = ttk.Button(
            self.button_frame, text="ETL code in python", command=self.display_etl_code)
        self.display_etl_button.pack(side=tk.LEFT, padx=5)

        self.file_contents = ""
        self.browsed_file_path = ""
        self.program_new_version = True

    # ---------------------------------------------------------------------------------------
    # FUNCTION - Read the browsed program, perform validations and show contents on left pane
    # ---------------------------------------------------------------------------------------
    def load_file(self):
        self.clear_contents()
        f.load_envvar()
        f.app_logger("browse started for user to select input file : ","info")    
        # Browse for the input file locationa and read the selected file
        file_path = filedialog.askopenfilename(
            filetypes=[("files", "*.txt")])
        if file_path:
            self.browsed_file_path = file_path
            self.file_path_label.config(text="Browsed File: " + file_path)
            self.file_contents = f.read_file(file_path)

            # validate if code provided is COBOL program
            if f.validate_cobol_code(self.file_contents):
                self.program_id = f.get_program_id(self.file_contents)

                # load the environment variables
                f.load_envvar(self.program_id)

                # process input file contents:
                # ...compare with previously processed version for same program
                self.verify_file()

                # Display the input file contents on left pane
                self.text_area.delete(1.0, tk.END)
                f.app_logger("display user program in left pane complete : ","info") 
                self.text_area.insert(tk.END, self.file_contents)
            else:
                # Display error
                err_msg = f.get_env_var("ERR_INVALID_PGM")
                self.text_area.delete(1.0, tk.END)
                self.text_area.insert(tk.END, err_msg)

    # sub-function for file comparision
    def verify_file(self):
        # set the file for input
        prev_input_version = f.get_file_full_path(
            f.get_env_var("INPUTS"), f.get_env_var("INPUT_FILE"))

        # check if the program is same as previous copy,
        # ...if same as before, show the previous copy
        # ...if not same as previous version, create new outputs
        if f.file_exists(prev_input_version):
            if f.compare_text_files(prev_input_version, self.browsed_file_path):
                self.program_new_version = False
            else:
                f.write_file(prev_input_version, self.file_contents)
        else:
            f.write_file(prev_input_version, self.file_contents)

    # -------------------------------------
    # FUNCTION - Clear the contents
    # -------------------------------------

    def clear_contents(self):
        self.file_contents = None
        self.program_new_version = True
        self.browsed_file_path = ""
        self.file_path_label.config(text="")
        self.text_area.delete(1.0, tk.END)
        self.updated_text_area.delete(1.0, tk.END)
        f.app_logger("clear content complete","info")  

    # -------------------------------------
    # FUNCTION - Display Pseudocode
    # -------------------------------------
    def display_updated(self):
        f.app_logger("display pseudocode logic started","info")  
        # Check if input file is selected,
        # process the logic to generate pseudocode
        if self.file_contents:
            self.process_pseudocode()
        else:
            err_msg = f.get_env_var("ERR_NO_INPUT")
            self.updated_text_area.delete(1.0, tk.END)
            self.updated_text_area.insert(tk.END, err_msg)
        f.app_logger("display pseudocode logic ended","info")  

    # -------------------------------------
    # FUNCTION - Display Summary
    # -------------------------------------
    def display_summary(self):
        f.app_logger("display summary logic started","info")  
        # Check if input file is selected,
        # process the logic to generate summary
        if self.file_contents:
            self.process_summ_code()
        else:
            err_msg = f.get_env_var("ERR_NO_INPUT")
            self.updated_text_area.delete(1.0, tk.END)
            self.updated_text_area.insert(tk.END, err_msg)
        f.app_logger("display summary logic ended","info")  

    # -------------------------------------
    # FUNCTION - Display etl code in python
    # -------------------------------------
    def display_etl_code(self):
        f.app_logger("display etl code logic started","info")  
        # Check if input file is selected,
        # process the logic to generate etl code
        if self.file_contents:
            self.process_etl_code()
        else:
            err_msg = f.get_env_var("ERR_NO_INPUT")
            self.updated_text_area.delete(1.0, tk.END)
            self.updated_text_area.insert(tk.END, err_msg)
        f.app_logger("display etl code logic ended","info")  

    # -------------------------------------
    # FUNCTION - pseudocode processing
    # -------------------------------------
    def process_pseudocode(self):
        # set files for outputs
        self.gpt_pseudo_output_file = f.get_file_full_path(f.get_env_var(
            "OPENAI_RESPONSES"), f.get_env_var("GPT_PSEUDO_RESPONSE"))
        self.app_pseudo_output_file = f.get_file_full_path(f.get_env_var(
            "OUTPUTS"), f.get_env_var("APP_PSEUDO_OUTPUT"))

        # check if the input file is new or has some updates.
        # otherwise use previous outputs to display on screen
        if self.program_new_version:
            pseudocode_output = self.prc_GPT_pseudocode()
        elif f.file_exists(self.app_pseudo_output_file):
            pseudocode_output = f.read_file(self.app_pseudo_output_file)
        else:
            pseudocode_output = self.prc_GPT_pseudocode()
        self.updated_text_area.delete(1.0, tk.END)
        self.updated_text_area.insert(tk.END, pseudocode_output)

    # sub-function :openai API call with pseudocode prompt
    def prc_GPT_pseudocode(self):
        # set the prompts
        usr_prompt = self.file_contents
        sys_prompt = f.get_env_var("PSEUDO_PROMPT")

        # get the key after decryption
        # OR ALTERNATELY USE --> openai.api_key = f.get_env_var("OPENAI_KEY")
        openai.api_key = f.get_openai_key()
        if f.is_internet_available():
            pseudocode_output = f.Ask_GPT(sys_prompt, str(
                usr_prompt), f.get_env_var("OPENAI_TIMEOUT"))
            if "openai_error" in pseudocode_output:
                err_msg = f.get_env_var("ERR_GPT_MSG1")
                return err_msg
            else:
                f.write_file(self.gpt_pseudo_output_file, pseudocode_output)
                f.write_file(self.app_pseudo_output_file, pseudocode_output)
                return pseudocode_output
        else:
             err_msg = f.get_env_var("ERR_GPT_MSG2")
             return err_msg


        

    # -------------------------------------
    # FUNCTION - summary processing
    # -------------------------------------
    def process_summ_code(self):
        # set files for outputs
        self.gpt_summary_output_file = f.get_file_full_path(f.get_env_var(
            "OPENAI_RESPONSES"), f.get_env_var("GPT_SUMMARY_RESPONSE"))
        self.app_summary_output_file = f.get_file_full_path(
            f.get_env_var("OUTPUTS"), f.get_env_var("APP_SUMMARY_OUTPUT"))

        # check if the input file is new or has some updates.
        # otherwise use previous outputs to display on screen
        if self.program_new_version:
            summary_output = self.prc_GPT_summary()
        elif f.file_exists(self.app_summary_output_file):
            summary_output = f.read_file(self.app_summary_output_file)
        else:
            summary_output = self.prc_GPT_summary()
        self.updated_text_area.delete(1.0, tk.END)
        self.updated_text_area.insert(tk.END, summary_output)

    # sub-function :openai API call with summary prompt
    def prc_GPT_summary(self):
        usr_prompt = self.file_contents
        sys_prompt = f.get_env_var("SUMMARY_PROMPT")

        # get the key after decryption
        # --OR-- CAN USE BELOW
        # -----> openai.api_key = f.get_env_var("OPENAI_KEY")
        openai.api_key = f.get_openai_key()
        if f.is_internet_available():
            summary_output = f.Ask_GPT(sys_prompt, str(
                usr_prompt), f.get_env_var("OPENAI_TIMEOUT"))
            if "error" in summary_output:
                err_msg = f.get_env_var("ERR_GPT_MSG1")
                return err_msg
            else:
                summary_json = json.loads(summary_output)
                summ_pgm = f.update_cob_with_summaries(
                    self.file_contents, summary_json)
                f.write_JSON(self.gpt_summary_output_file, summary_json)
                f.write_file(self.app_summary_output_file, summ_pgm)
                return summ_pgm
        else:
             err_msg = f.get_env_var("ERR_GPT_MSG2")
             return err_msg

    # -------------------------------------
    # FUNCTION - etl code processing
    # -------------------------------------
    def process_etl_code(self):
        # check if the input file is new or has some updates.
        # otherwise use previous outputs to display on screen
        self.app_pseudo_output_file = f.get_file_full_path(f.get_env_var(
            "OUTPUTS"), f.get_env_var("APP_PSEUDO_OUTPUT"))
        self.gpt_etl_output_file = f.get_file_full_path(f.get_env_var(
            "OPENAI_RESPONSES"), f.get_env_var("GPT_PYTHON_OUTPUT"))
        self.app_etl_output_file = f.get_file_full_path(f.get_env_var(
            "OUTPUTS"), f.get_env_var("APP_PYTHON_OUTPUT"))
        # check if the input file is new or has some updates.
        # otherwise use previous outputs to display on screen
        if self.program_new_version:
            etl_output = self.prc_GPT_etl_code()
        elif f.file_exists(self.app_etl_output_file):
            etl_output = f.read_file(self.app_etl_output_file)
        else:
            etl_output = self.prc_GPT_etl_code()

        self.updated_text_area.delete(1.0, tk.END)
        self.updated_text_area.insert(tk.END, etl_output)

    # sub-function :openai API call with etl prompt
    def prc_GPT_etl_code(self):
        if f.file_exists(self.app_pseudo_output_file):
            usr_prompt = f.read_file(self.app_pseudo_output_file)
            sys_prompt = f.get_env_var("ETL_PROMPT")

            # get the key after decryption
            # OR ALTERNATELY USE --> openai.api_key = f.get_env_var("OPENAI_KEY")
            openai.api_key = f.get_openai_key()
            if f.is_internet_available():
                etl_output = f.Ask_GPT(sys_prompt, str(
                usr_prompt), f.get_env_var("OPENAI_TIMEOUT"))
                if "openai_error" in etl_output:
                    err_msg = f.get_env_var("ERR_GPT_MSG1")
                    return err_msg
                else:
                    f.write_file(self.gpt_etl_output_file, etl_output)
                    f.write_file(self.app_etl_output_file, etl_output)
                    return etl_output
            else:
                err_msg = f.get_env_var("ERR_GPT_MSG2")
                return err_msg
        else:
            err_msg = f.get_env_var("ERR_NO_PSUEDO_EXISTS")
            return err_msg

# ------------------------------------------------
#  M A I N - P R O C E S S I N G - F U N C T I O N
# ------------------------------------------------
def main():
    f.app_logger("app started","info")  
    root = tk.Tk()
    editor = TextFileEditor(root)
    root.mainloop()
    f.app_logger("app closed","info")  
