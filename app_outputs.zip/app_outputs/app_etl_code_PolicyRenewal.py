Here is the AWS Glue code in Python that mimics the functionality of the original COBOL program:

```python
# Read the PolicyDB2File data into the PolicyDB2Record array
PolicyDB2File = glueContext.create_dynamic_frame.from_catalog(database = "your_database", table_name = "PolicyDB2File")
PolicyDB2Record = PolicyDB2File.toDF().collect()

# Initialize the Record-Count variable to 1
Record_Count = 1

# Start a loop until Record-Count is greater than 10
while Record_Count <= 10:
    # Move the Policy-Type from PolicyDB2Record to PolicyRecord
    PolicyRecord = PolicyDB2Record[Record_Count - 1]["Policy-Type"]

    # Check the value of PolicyRecord.Policy-Type
    if PolicyRecord == "CAR_INSURANCE":
        # Move 200000 to PolicyRecord.Coverage-Limits
        Coverage_Limits = 200000
        # Move 1200 to PolicyRecord.Policy-Premium
        Policy_Premium = 1200
    elif PolicyRecord == "HOME_INSURANCE":
        # Move 600000 to PolicyRecord.Coverage-Limits
        Coverage_Limits = 600000
        # Move 2400 to PolicyRecord.Policy-Premium
        Policy_Premium = 2400
    elif PolicyRecord == "LIFE_INSURANCE":
        # Move 1200000 to PolicyRecord.Coverage-Limits
        Coverage_Limits = 1200000
        # Move 3600 to PolicyRecord.Policy-Premium
        Policy_Premium = 3600
    else:
        # Move 0 to PolicyRecord.Coverage-Limits
        Coverage_Limits = 0
        # Move 0 to PolicyRecord.Policy-Premium
        Policy_Premium = 0

    # Move PolicyRecord.Coverage-Limits to Coverage-Limits(Record-Count)
    Coverage_Limits_Record_Count = Coverage_Limits

    # Move PolicyRecord.Policy-Premium to Policy-Premium(Record-Count)
    Policy_Premium_Record_Count = Policy_Premium

    # Increment the Record-Count by 1
    Record_Count += 1

# Exit the program
```

Please note that you need to replace "your_database" with the actual name of your database in the `glueContext.create_dynamic_frame.from_catalog` function. Also, make sure to adjust the table name accordingly.