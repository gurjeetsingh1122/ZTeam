Here is the AWS Glue code in Python that mimics the functionality of the original COBOL program:

```python
# Import necessary libraries
import pandas as pd
import ibm_db_dbi as dbi
import ibm_db

# Establish a connection with the DB2 database
conn = ibm_db.connect("DATABASE=your_db_name;HOSTNAME=your_host_name;PORT=your_port_number;PROTOCOL=TCPIP;UID=your_username;PWD=your_password;", "", "")

# Fetch data from DB2 tables and store it in a pandas DataFrame
query = "SELECT * FROM your_table_name"
df = pd.read_sql(query, conn)

# Sort the DataFrame based on the sort key
df = df.sort_values(by=['sort_key'])

# Calculate the total premium amount
total_premium_amount = df['premium_amount'].sum()

# Generate the policy summary report
policy_summary_report = df.groupby(['policy_type']).agg({'policy_number': 'count', 'premium_amount': 'sum'}).reset_index()

# Write the report to the PolicyIMSFile
with open('PolicyIMSFile.txt', 'w') as file:
    file.write(policy_summary_report.to_string())

# Close the DB2 connection
ibm_db.close(conn)

# End the program
```

Please note that you need to replace the placeholders (`your_db_name`, `your_host_name`, `your_port_number`, `your_username`, `your_password`, `your_table_name`) with the actual values specific to your DB2 database. Also, make sure you have the necessary Python libraries (`pandas`, `ibm_db_dbi`, `ibm_db`) installed in your AWS Glue environment.