# --------------------------------------------------------------------------------------
#                         C O M M O N - F U N C T I O N S
# --------------------------------------------------------------------------------------

import openai
import json
import os
from cryptography.fernet import Fernet
import base64
import sys
import re
import logging
import requests

###########################################################################################
#   Functions to get CWD and config parameters
###########################################################################################
# get and set function for the current working directory of main program


def set_cwd():
    os.chdir(os.path.dirname(os.path.abspath(sys.argv[0])))


def get_cwd():
    return str(os.path.dirname(os.path.abspath(sys.argv[0])))


# Get the config parm value.
def get_cfg_dict():
    set_cwd()
    cfg = read_JSON('config.json')
    return cfg


# Given a key, return the value in the config dictionary
def get_config_key_value(cfg, input_key):
    for key, value in cfg.items():
        if key == input_key:
            return str(value)


# Load config variables to environment
def load_envvar(pgm_name=None):
    cfg = get_cfg_dict()
    if pgm_name==None:
        for key, value in cfg.items():
            if "$PGMNAME" not in value:
                os.environ[key] = str(value)  
        app_logger("loaded constant config parms to environment variables ","info")      
    else:
        for key, value in cfg.items():
            if "$PGMNAME" in value:
                upd_val = value.replace("$PGMNAME", pgm_name)
                os.environ[key] = str(upd_val)
        app_logger("loaded program specific config parms to environment variables ","info") 
    
def display_environment_variables():
    for key, value in os.environ.items():
        print(f"{key}: {value}")

# get an enviornment variable
def get_env_var(key):
    value = str(os.environ.get(key))
    if value==None:
        app_logger(f"environment variable not found : {key} ","error")  
        return ""
    return value

# get full path of a file 
def get_file_full_path(file_path, file_name):
    cwd = get_cwd()
    return str(cwd+file_path+file_name)



###########################################################################################
#   Logging functions
###########################################################################################

def create_logger_instance():
    #cwd=get_cwd()
    #file_path=cwd+"\\logs\\"+"application.log"
    file_path=get_file_full_path(get_env_var("LOG_PATH"), "application.log")
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    # Creating an object
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    file_handler = logging.FileHandler(file_path)
    file_handler.setLevel(logging.DEBUG)  
    # Create a formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')  
    # Set the formatter for the handler
    file_handler.setFormatter(formatter)
    # Add the handler to the logger
    logger.addHandler(file_handler)
    return logger

# create logger instance for current session
logger = create_logger_instance()

def app_logger(message,level):
    # Setting the threshold of logger to DEBUG
    if level=="info":
        logger.info(message)
    elif level=="debug":
        logger.debug(message)
    elif level=="warning":
        logger.warning(message)
    elif level=="error":
        logger.error(message)
    elif level=="critical":
        logger.critical(message)
    elif level=="fatal":
        logger.fatal(message)

###########################################################################################
#   Check if internet is available
###########################################################################################
def is_internet_available():
    try:
        response = requests.get("https://openai.com/blog/chatgpt", timeout=5)
        response.raise_for_status()  # Raise an exception if the response status is not OK
        app_logger("INTERNET UP: ","info")
        return True
    except requests.RequestException:
        app_logger("INTERNET DOWN : ","fatal")
        return False



###########################################################################################
#   File read/write functions in text/json format
###########################################################################################




# check if a file exists or not
def file_exists(path):
    return os.path.isfile(path)


# Get the program-id from the file
def get_program_id(contents):
    lines = contents.split("\n")
    for line in lines:
        if "PROGRAM-ID. " in line:
            pgm_id_idx = line.index("PROGRAM-ID. ")+len("PROGRAM-ID. ")

            pgm_name = line[pgm_id_idx:].strip().rstrip('.')
            return pgm_name
    return ""


# Read a JSON file :
def read_JSON(file_path):
    try:
        app_logger("Reading JSON : "+file_path,"info")
        with open(file_path, 'r') as json_file:
            json_data = json.load(json_file)
            # print(json_data)
            return json_data
    except FileNotFoundError:
        app_logger(f"JSON File '{file_path}' not found.","error")
        return []
        


# write a JSON file :
def write_JSON(file_path, json_data):
    try:
        with open(file_path, 'w') as json_file:
            json.dump(json_data, json_file, indent=4)
        app_logger("Writing JSON : "+file_path,"info")
    except Exception as e:
        app_logger(f"Exception {str(e)} occured while writing JSON {file_path}.","critical")

#  Read a text file
def read_file(file_path):
    try:
        app_logger("Reading file : "+file_path,"info")
        with open(file_path, 'r') as file:
            content = file.read()
            return content  
    except FileNotFoundError:
        app_logger(f"File '{file_path}' not found.","error")
        return []

#  Read a text file using readlines
def read_file_lines(file_path):
    try:
        app_logger("Reading file : "+file_path,"info")
        with open(file_path, 'r') as file:
            content = file.readlines()
            return content
    except FileNotFoundError:
        app_logger(f"File '{file_path}' not found.","error")
        return []

# Write a file :
def write_file(file_path, content_list):
    try:
        with open(file_path, 'w') as file:
            for line in content_list:
                file.write(line) 
        app_logger("Writing file : "+file_path,"info")
    except Exception as e:
        app_logger(f"Exception {str(e)} occured while writing file {file_path}.","critical")


#
#
###########################################################################################
#   FUNCTION -
#          Compare 2 text files and return true/false
###########################################################################################


def remove_extra_spaces(line):
    return ' '.join(line.split())


def compare_text_files(file1_path, file2_path):
    app_logger(f"previous version exists for user input program : comparing user input vs previous version : {file1_path} vs {file2_path} ","info")
    lines1=read_file_lines(file1_path)
    lines2=read_file_lines(file2_path)

    # Remove leading and trailing whitespace from each line
    lines1 = [line.strip() for line in lines1]
    lines2 = [line.strip() for line in lines2]

    # Remove empty lines from the lists
    lines1 = [line for line in lines1 if line]
    lines2 = [line for line in lines2 if line]

    if len(lines1) != len(lines2):
        app_logger(f"differences found between selected and previous version : {file1_path} vs {file2_path} ","info")
        return False

    for line1, line2 in zip(lines1, lines2):
        line1_cleaned = remove_extra_spaces(line1)
        line2_cleaned = remove_extra_spaces(line2)
        if line1_cleaned != line2_cleaned:
            app_logger(f"differences found between selected and previous version : {file1_path} vs {file2_path} ","info")
            return False
    app_logger(f"same contents in selected and previous version : {file1_path} vs {file2_path} ","info")
    return True


#
#
###########################################################################################
#   Key encrypt / decrypt functions
#          Encrypt functions
#          Decrypt functions
###########################################################################################

# Encrypt the openai key using the Random key and encrypted key

def encrypt_openai_key(openai_Key):
    app_logger(f"encryption logic start ","info")

    # generate the random key to be used for encryption and decode
    random_key=get_file_full_path(get_env_var("KEY_PATH"), "encryption_key")
    encrypted_key=get_file_full_path(get_env_var("KEY_PATH"), "encrypted_key")
    # Write Encrypted key
    encryption_key = Fernet.generate_key()
    cipher_suite = Fernet(encryption_key)
    encrypted_data = cipher_suite.encrypt(openai_Key.encode()).decode()
    with open(encrypted_key, 'w') as file:
        file.write(encrypted_data)
        app_logger(f"Writing file : {encrypted_key} ","info")
    # Write random key
    base64_datakey = base64.urlsafe_b64encode(encryption_key).decode('utf-8')
    write_file(random_key, base64_datakey)
    app_logger(f"encryption logic end ","info")
    #encrypted_data = cipher_suite.encrypt(openai_Key.encode())




# Decrypt the openai key using the Random key and encrypted key
def get_openai_key():
    app_logger(f"decryption logic start ","info")
    random_key = get_file_full_path(
        get_env_var("KEY_PATH"), "encryption_key")
    encrypted_key = get_file_full_path(
        get_env_var("KEY_PATH"), "encrypted_key")
    # read the random key used for encryption and decode
    random_key_contents = read_file_lines(random_key)
    encryption_key = base64.urlsafe_b64decode(random_key_contents[0])
    cipher_suite = Fernet(encryption_key)
    # Read the encrypted key file
    decrypted_key = read_and_decrypt(encrypted_key, cipher_suite)
    app_logger(f"decryption logic end ","info")
    return decrypted_key



# Decrypt the key
def read_and_decrypt(input_file, cipher_suite):
    try:
        app_logger(f"reading file from {input_file} ","info")
        with open(input_file, 'rb') as file:
            encrypted_data = file.read()
            decrypted_data = cipher_suite.decrypt(encrypted_data)
            return decrypted_data.decode()
    except Exception as e:
        print(f"file {input_file} not found:", str(e))



###########################################################################################
#   OPENAI functions
#         1. Chat API with GPT-3.5
###########################################################################################


# FUNCTION to use chat-gpt model
def Ask_GPT(sys_content, user_content, timeout_seconds):
    check_net=is_internet_available()    
    if check_net:
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {
                     "role": "system",
                     "content": sys_content
                    },
                    {
                        "role": "user",
                        "content": user_content
                    }
                ],
                temperature=0,
                max_tokens=2000,
                timeout=timeout_seconds
            )
        except openai.error.OpenAIError:
            app_logger(f"Exception {openai.error.OpenAIError} returned from openai","critical")
            return {"openai_error": "API request error"}
        
        app_logger(f"response successfully received from openai.","info")
        return response.choices[0].message["content"]
    else:
        app_logger(f"request not sent to openai","error")
        error : {"openai_error": "Not connected to internet, please check your connection"}
        return error

###########################################################################################
#    Data manipulation
#         1. Repeat a string
#         2. Get postion of a string within another string
#         3. Function to split a long string into mutiple lines based on line-length & pfx
#         4. Add summaries function to cobol using cobol program, summaries
###########################################################################################

# Function to repeat a string 'n' number of times
def repeat_Str(str, n):
    return str*n


# Function to return the position of the string
def pos_str(master, needle):
    match = (re.search(needle, master))
    if match.start() > 0:
        return int(match.start())
    else:
        return 0


# Function to split a line into multiple lines based on input length
def split_sentence_with_prefix(sentence, line_length, prefix):
    words = sentence.split()
    lines = []
    current_line = prefix + words[0]

    for word in words[1:]:
        if len(current_line) + len(word) + 1 <= line_length:
            current_line += ' ' + word
        else:
            lines.append(current_line)
            current_line = prefix + word

    if current_line:
        lines.append(current_line)

    return lines


# Function to add summaries before paragraphs given cobol code
def update_cob_with_summaries(cobol_code, paragraph_summaries):
    lines = cobol_code.split("\n")

    new_code = []
    current_paragraph = ""

    for line in lines:
        if line.strip().endswith("."):
            current_paragraph = line.strip()[:-1]
            if "PROCEDURE DIVISION" in current_paragraph:
                current_paragraph = 'PROCEDURE DIVISION'
            if current_paragraph in paragraph_summaries:
                summary = paragraph_summaries[current_paragraph]
                pos = pos_str(line, current_paragraph)
                if pos == 1:
                    border_line = repeat_Str("*", 50)
                    new_code.append(border_line)
                    summary_list = split_sentence_with_prefix(
                        summary, 50, "**")
                    for summ_line in summary_list:
                        new_code.append(summ_line)
                    new_code.append(border_line)
                else:
                    prefix = repeat_Str(" ", (pos-1))+"**"
                    border_line = prefix+repeat_Str("*", 50-len(prefix))
                    new_code.append(border_line)
                    summary_list = split_sentence_with_prefix(
                        summary, (50-len(prefix)), prefix)
                    for summ_line in summary_list:
                        new_code.append(summ_line)
                    new_code.append(border_line)
        new_code.append(line)

    return "\n".join(new_code)


# function to validate if given piece of code is a valid COBOL program.

def validate_cobol_code(cobol_code):
    # Basic COBOL program structure: IDENTIFICATION DIVISION, ...
    program_structure_pattern = re.compile(
        r'IDENTIFICATION\s+DIVISION.*\s+PROGRAM-ID.*', re.IGNORECASE)

    # Check if program structure is present
    if not program_structure_pattern.search(cobol_code):
        app_logger(f"selected input is not valid cobol program","error")
        return False

    # More validation checks can be added here, such as checking for
    # correct paragraphs, sections, statements, etc.
    app_logger(f"selected input is a valid cobol program","info")
    return True
