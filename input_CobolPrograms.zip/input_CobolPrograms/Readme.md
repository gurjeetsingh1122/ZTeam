This folder contains all the cobolo Programs in scope for this Use Case
